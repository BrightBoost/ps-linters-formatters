#WorkMate

A simple app to manage personal tasks, meetings, and action items


##Features
-Add people  
*Add meetings
  -  Add action items and assign them
 -mark them done  
- light/dark mode toggle 

##Usage

1.Install dependencies (if any)

2. Run the app (no build step needed)

3.View and manage todos in browser


##License
MIT
